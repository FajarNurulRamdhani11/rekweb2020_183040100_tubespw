// ambil elemen2 yang dibutuhkan

var keyword = document.getElementById('keyword');
var tombolCari = document.getElementById('tombol-cari');
var sectionContainer = document.getElementById('section-container');

tombolCari.addEventListener('click', function() {
	alert('berhasil!!');
});