<?php

require '../Fungsi/function.php';
	if( isset($_POST["login"]) ) {
		
		$username = $_POST["username"];
		$password = $_POST["password"];

		$result = mysqli_query($conn, "SELECT *FROM user WHERE username = '$username'");

		//cek username
		if( mysqli_num_rows($result) === 1 ) {
			
			//cek password
			$row = mysqli_fetch_assoc($result);
			if( password_verify($password, $row["password"]) ) {
				header("Location: ../Fungsi/index.php");
				exit;
			}
		}

		$error = true;
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
	<style>
		label {
			display: block;
		}
		.container{
	width: 280px;
	height: center;
	background-color: lightblue;
	margin: 0 auto;
	position: relative;
	text-align: center;
}
		.img {
			width: 100px;
		}

	</style>
</head>
<body>
	
	
	<form action="" method="post">
		<div class="container">
			<h1>Halaman Login</h1>
		<ul>
			<img src="../img/logo.jpg" class="img">
			<?php if( isset($error)) : ?>
	<p style="color: red"> Username/Password anda Salah</p>
	<?php endif; ?>
			<li>
				<label for="username">username :</label>
				<input type="text" name="username" id="username">
			</li>
			<li>
				<label for="password"> password</label>
				<input type="password" name="password" id="password">
			</li>
				<button type="submit" name="login">Login</button><br>
				<button type="submit" name="Back"><a href="../User/user.php">Back</a>
				</button>
			
		</ul>


	</div>


</body>
</html>