<?php
require '../Fungsi/function.php';

$no = $_GET["No"];
$elektronik = query("SELECT * FROM elektronik WHERE No = $no")[0];


// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	
	// cek apakah data berhasil diubah atau tidak
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = 'index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = 'index.php';
			</script>
		";
	}

 }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ubah data</title>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<h1>Ubah data elektronik</h1>

	<form action="" method="post" enctype="multipart/form-data">
		<input type="hidden" name="No" value="<?= $elektronik["No"]; ?>">
		<input type="hidden" name="gambarlama" value="<?= $elektronik["Gambar"]; ?>">
		<ul>
			<li>
				<label for="Nama">Nama : </label>
				<input type="text" name="Nama" id="Nama" required value="<?= $elektronik["Nama"]; ?>">
			</li>
			<li>
				<label for="Gambar">Gambar : </label>
				<input type="file" name="Gambar" id="Gambar" value="<?= $elektronik["Gambar"]; ?>">
			</li>
			<li>
				<label for="Harga">Harga :</label>
				<input type="text" name="Harga" id="Harga" value="<?= $elektronik["Harga"]; ?>">
			</li>
			<li>
				<label for="Fungsi">Fungsi :</label>
				<input type="text" name="Fungsi" id="Fungsi" value="<?= $elektronik["Fungsi"]; ?>">
			</li>
			<li>
				<label for="Penemu">Penemu :</label>
				<input type="text" name="Penemu" id="Penemu" value="<?= $elektronik["Penemu"]; ?>">
			</li>
			<li>
				<button class="btn waves-effect waves-light" type="submit" name="submit">ubah	
    			<i class="material-icons right">all_inclusive</i>
  				</button>
			</li>
		</ul>

	</form>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>


