<?php
require 'function.php';

// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	
	// cek apakah data berhasil di tambahkan atau tidak
	if( tambah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	}

}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data BARU</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
<form action="" method="post" enctype="multipart/form-data">
	<ul>
		<li>
			<label for="No">No :</label>
			<input type="text" name="No" id="No">
		</li>
		<li>
			<label for="Nama">Nama :</label>
			<input type="text" name="Nama" id="Nama">
		</li>
		<li>
			<label for="Gambar">Gambar :</label>
			<input type="file" name="Gambar" id="Gambar">
		</li>
		<li>
			<label for="Harga">Harga :</label>
			<input type="text" name="Harga" id="Harga">
		</li>
		<li>
			<label for="Fungsi">Fungsi :</label>
			<input type="text" name="Fungsi" id="Fungsi">
		</li>
		<li>
			<label for="Penemu">Penemu :</label>
			<input type="text" name="Penemu" id="Penemu">
		</li>
	</ul>

<button class="btn waves-effect waves-light" type="submit" name="submit" id="submit">Submit
    <i class="material-icons right">send</i>
  </button>




</form>








    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</body>
</html>