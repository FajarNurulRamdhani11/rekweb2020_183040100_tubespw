<?php
$conn = mysqli_connect("localhost", "root", "", "phpdasar");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}
function tambah($data) {
	global $conn;

	$No = htmlspecialchars($data["No"]);
	$Nama = htmlspecialchars($data["Nama"]);
	$Harga = htmlspecialchars($data["Harga"]);
	$Fungsi = htmlspecialchars($data["Fungsi"]);
	$Penemu = htmlspecialchars($data["Penemu"]);

	$Gambar = upload();
	if ( !$Gambar ) {
		 return false;
	}

	$query = "INSERT INTO elektronik
				VALUES
			  ('$No', '$Nama', '$Gambar', '$Harga', '$Fungsi','$Penemu')
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}
function hapus($No) {
	global $conn;
	mysqli_query($conn, "DELETE FROM elektronik WHERE No = $No");
	return mysqli_affected_rows($conn);
}


function upload() {

	$namaFile = $_FILES['Gambar']['name'];
	$ukuranFile = $_FILES['Gambar']['size'];
	$error = $_FILES['Gambar']['error'];
	$tmpName = $_FILES['Gambar']['tmp_name'];

	// cek apakah tidak ada gambar yang diupload
	if( $error === 4 ) {
		echo "<script>
				alert('pilih gambar terlebih dahulu!');
			  </script>";
		return false;
	}

	// cek apakah yang diupload adalah gambar
	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
		echo "<script>
				alert('yang anda upload bukan gambar!');
			  </script>";
		return false;
	}

	// cek jika ukurannya terlalu besar
	if( $ukuranFile > 10000000000 ) {
		echo "<script>
				alert('ukuran gambar terlalu besar!');
			  </script>";
		return false;
	}

	// lolos pengecekan, gambar siap diupload
	// generate nama gambar baru
	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ekstensiGambar;

	move_uploaded_file($tmpName, '../img/' . $namaFileBaru);

	return $namaFileBaru;
}



function ubah($data) {
	global $conn;

	$No = $data["No"];
	$Nama = htmlspecialchars($data["Nama"]);
	$Harga = htmlspecialchars($data["Harga"]);
	$Fungsi = htmlspecialchars($data["Fungsi"]);
	$Penemu = htmlspecialchars($data["Penemu"]);
	$gambarlama = htmlspecialchars($data["gambarlama"]); 
	
	// cek user pilih gambar atau tidak
	if ( $_FILES['Gambar']['error'] === 4) {
		$Gambar = $gambarlama;
	} else {
		$Gambar = upload ();
	}

	$query = "UPDATE elektronik SET
				Nama = '$Nama',
				Gambar = '$Gambar',
				Harga = '$Harga',
				Fungsi = '$Fungsi',
				Penemu = '$Penemu'
			  WHERE No = $No
			";
	mysqli_query($conn, $query);

		return mysqli_affected_rows($conn);	
	}

function cari($keyword) {
    $query = "SELECT * FROM elektronik WHERE
    nama LIKE '%$keyword%' 
 
    ";
    return query($query);
}

function registrasi($data) {
	global $conn;

	$username = strtolower(stripslashes($data["username"]));
	$password = mysqli_real_escape_string($conn, $data["password"]);
	$password2 = mysqli_real_escape_string($conn, $data["password2"]);

	//cek username sudah ada atau belum
	$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");

	if( mysqli_fetch_assoc($result) ) {
		echo "<script>
				alert('username sudah terdaftar!')
				</script>";
			return false;
	}

	//cek konfirmasi password

	if( $password !== $password2 ) {
		echo "<script>
				alert('konfitmasi password tidak sesuai!');
				</script>";

			return false;
	}
	// enkripsi password

	$password = password_hash($password, PASSWORD_DEFAULT);


	//tambahkan user baru ke database
	mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password')");

	return mysqli_affected_rows($conn);
}

?>