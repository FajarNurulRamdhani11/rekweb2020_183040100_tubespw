<?php 

require '../Fungsi/function.php';
$elektronik = query("SELECT * FROM elektronik");

if ( isset($_POST["cari"])) {
  $elektronik = cari($_POST["keyword"]);
}


 ?>

<!DOCTYPE html>
<html>
    <head>
        <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="../Css/materialize.min.css"  media="screen,projection"/>
        <link rel="stylesheet" type="text/css" href="../Css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
    <title>Electronic Store</title>
    <body id="home" class="scrollspy">
        <!-- buat navbar -->
        <div class="navbar-fixed">
             <nav class="black lighten-3">
                <div class="container">
                    <div class="nav-wrapper">
                        <a href="#home" class="brand-logo"><img id="logo" src="" >Electronic Store</a>
                        <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                        <form action="" method="POST">
                        <ul class="right hide-on-med-and-down">
                             <li><a href="profile.php">Profile</a></li>
                             <li><a href="#Product">Product</a></li>
                             <li><a href="#contact">Pemesanan</a></li>
                             <li><a href="../Admin/login.php"> Login</a></li>
                             <li><a href="../Fungsi/registrasi.php"><i class="material-icons small">add_box</i></a></li>
                             <li><a href="#Product"></a><i class="material-icons small"><input type="text" name="keyword" size="40" autofocus placeholder="masukkan nama barang yang anda cari.." autocomplete="off"><button type="submit" name="cari"><a href="#Product"></a> Cari!</button>
                             </i></li>

                        </ul>
                        </form>
                   </div>
                </div>  
            </nav>
         </div>
  <ul class="sidenav grey lighten-2" id="mobile-nav">
        <i class="material-icons medium">local_shipping</i>
         <li><a href="#about">Profile</a></li>
          <li><a href="#clients">Product</a></li>
          <li><a href="#services">Pemesanan</a></li>
          <li><a href="../Admin/login.php">Login</a></li>
          <li><a href="../Fungsi/registrasi.php"><i class="material-icons small">add_box</i>register</a></li>
         
  </ul>
    <!-- random image -->
   <div class="slider">
    <ul class="slides">
      <li>
        <img src="../img/slide1.jpg"> 
        <div class="caption left-align">
          <h3> <br><br><br>like shoes that are witnesses to the struggle .</h3>
          <h5 class="light grey-text text-lighten-3">Holla Amigos!</h5>
        </div>
      </li>
      <li>
        <img src="../img/slide2.jpg"> <!-- random image -->
        <div class="caption center-align">
          <h3><br><br>Continue to move what you have started and enjoy each step you will pass.</h3>
          <h5 class="light grey-text text-lighten-3">never think of giving up.</h5>
        </div>
      </li>
      <li>
        <img src="../img/slide3.jpg"> <!-- random image -->
        <div class="caption right-align">
          <h3><br><br>DON'T FORGET TO  BUY AND HAPPY SHOOPING.</h3>
          <h5 class="light grey-text text-lighten-3">Panda</h5>
        </div>
      </li>
    </ul>
   </div>  

      <section id="services" class="sercives grey lighten-3 scrollspy">
        <div class="container">
            <div class="row">
                <h3 class="light center grey-text text-darken-3">Our Services</h3>
                <div class="col m4 s12">
                    <div class="card-panel center grey lighten-2">
                        <i class="material-icons medium">computer</i>
                        <h5>Laptop</h5>
                        <p>we provide various kinds of laptop products.</p>
                    </div>
                </div>
                <div class="col m4 s12">
                    <div class="card-panel center grey lighten-2">
                        <i class="material-icons medium">developer_mode</i>
                        <h5>Smartphone</h5>
                        <p>we provide various kinds of laptops and smartphones products.</p>
                    </div>
                </div>
                <div class="col m4 s12">
                    <div class="card-panel center grey lighten-2">
                        <i class="material-icons medium">videogame_asset</i>
                        <h5>Accesoris for Game</h5>
                        <p>we also provide various products for accessories in playing games.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>


<section id="Product" class="Product scrollspy">
        <div class="container">
          <h3 class="light grey-text text-darken-3 center"> Our Product</h3>
        <?php foreach($elektronik as $nama) : ?>
        <div class="col m4 s12">
          <div class="row">
          <div class="card-content">
            <div class="card-title">
            <div>
              <a><?= $nama["No"]; ?></a>
            </div>
            <ul class="collection">
              <li class="collection-item"><?= $nama["Nama"]; ?></li>
              <li class="collection-item"><img class="gambar" src="../img/<?= $nama["Gambar"]; ?>"></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
    </section>
       <section id="clients" class="clients scrollspy">
     <div class="parallax-container">
      <div class="parallax"><img src="../img/open.jpg"></div>

      <div  class="container clients">
         <h3 class="center light white-text">Our Clients</h3>
         <br><br>
         <div class="row">
             <div class="col m4 s12 center">
                 <img src="../img/gojek.png">
             </div>
               <div class="col m4 s12 center">
                 <img src="../img/jne.png">
             </div>
               <div class="col m4 s12 center">
                 <img src="../img/grab.png">
             </div>
         </div> 
      </div>

    </div>

  </section>

   <section id="contact" class="contact scrollspy">
        <div class="container">
            <h3 class="light grey-text text-darken-3 center">Contact Us</h3>
            <div class="row">
                <div class="col m4 s12">
                    <div class="card-panel grey darken-2 center white-text">
                        <i class="material-icons">email</i>
                        <h5>Contact</h5>
                        <p> You can contact me in google mail <br> framdhani11@gmail.com
                            <br>
                              or
                              <br>
                            Number phone : 081320344475
                          </p>
                    </div>
                    <div class="grey lighten-2">
                    <ul class="collection with-header">
                        <li class="collection-header"><h4>Our Office</h4></li>
                        <li class="collection-item">xPANDAMANx</li>
                        <li class="collection-item">Jl. Setiabudhi No. 193, Bandung</li>
                        <li class="collection-item">West Java, Indonesian</li>
                    </ul>
                  </div>
                </div>


                <div class="col m7 s12">
                    <form>
                        <div class="card-panel black-text grey lighten-2">
                            <h5>Untuk pemesanan</h5>
                            <div class="input-field">
                                <input type="text" name="name" id="name" required class="validate">
                                <label for="name">Name</label>
                            </div>
                            <div class="input-field">
                                <input type="text" name="Product" id="Product">
                                <label for="Product"> Name of Product</label>
                            </div>
                            <div class="input-field">
                                <input type="email" name="name" id="email" class="validate">
                                <label for="email">Email</label>
                            </div>
                            <div class="input-field">
                                <input type="text" name="phone" id="phone">
                                <label for="phone">Phone Number</label>
                            </div>
                            <div class="input-field">
                               <textarea name="message" id="message" class="materialize-textarea"> </textarea>
                                <label for="message">Message</label>
                            </div>
                            <button type="submit" class="btn grey darken-2"><i class="material-icons small">local_shipping</i></button>
                        </div>
                     </form>
                </div>
            </div>
        </div>
    </section>

<!-- back to top -->
    
    <div id="btt">
      <a href="#"title="back to top"><img src="../img/backtop.png"></a>
    </div>
<!-- FOOTER -->
    <footer id="footer"class="grey darken-2 white-text center">
        <p class="flow-text">&copy; 2019 | built by. xPANDAMANx</p>
        <p class="flow-text"><a href="http://instagram.com/anakpaksubarna" class="btn grey ">Support</a></p>
    </footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../Css/style.css">
        <!--JavaScript at end of body for optimized loading-->
        <script type="text/javascript" src="../JS/materialize.min.js"></script>
        <script> 
            const sidenav = document.querySelectorAll('.sidenav');
            M.Sidenav.init(sidenav)


             const slider = document.querySelectorAll('.slider');
             M.Slider.init(slider, {
                indicators:false,
                height:400,
                transition:600,
                interval:3000

             }); 

             const parallax =  document.querySelectorAll('.parallax')   
             M.Parallax.init(parallax);


             const materialbox = document.querySelectorAll('.materialboxed')
             M.Materialbox.init(materialbox)

             const scroll = document.querySelectorAll('.scrollspy')
             M.ScrollSpy.init(scroll, {
                scrollOffset: 50
             })
      </script>

    </body>
</html>
